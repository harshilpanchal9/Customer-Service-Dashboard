from google.cloud import firestore
# need to check if we need to do any kind of connection management
#todo
db_client = firestore.Client()