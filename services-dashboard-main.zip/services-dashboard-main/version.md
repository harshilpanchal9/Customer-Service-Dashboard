1.0
>⚠ Please do not change this file, It is updated for version number and changelog when a new release is made
## Changelog
### Version 1.0
1. Release date - 21-January-2023
2. Initial version
3. Python 3.9+ and Angular 15
4. Following functionalities are provided
   1. Adding, deleting and updating services including status update
   2. Dashboard
   3. Alert notification
   4. Update application wide settings
   5. API endpoint for updating service status

    
